const firebaseConfig = {
  apiKey: "AIzaSyB7HYJkZEM6LmeBHclmlm089JdXe12V18s",
  authDomain: "mappysteps-b0a92.firebaseapp.com",
  databaseURL: "https://mappysteps-b0a92.firebaseio.com",
  projectId: "mappysteps-b0a92",
  storageBucket: "mappysteps-b0a92.appspot.com",
  messagingSenderId: "409010553646",
  appId: "1:409010553646:web:9c4f95daf483501e11f0bf"
  };

  export default firebaseConfig

import {AfterViewInit, Component, ElementRef, OnInit, ViewChild} from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import { AlertController } from '@ionic/angular';
import { Geolocation } from '@ionic-native/geolocation/ngx';
import { Router } from '@angular/router'

declare var google;
var map;
var gcounter=0;
var scounter=0;
var gRoute=[];
var sRoute;
var resp;
var startMarker;
var endMarker;


@Component({
  selector: 'app-navigate',
  templateUrl: './navigate.page.html',
  styleUrls: ['./navigate.page.scss'],
})
export class NavigatePage implements OnInit, AfterViewInit {
  @ViewChild('mapElement', { static: true }) mapNativeElement;
  @ViewChild('directionsPanel', {static: false }) directionsPanel: ElementRef;
  directionsService = new google.maps.DirectionsService;
  directionsDisplay= new google.maps.DirectionsRenderer;
  directionForm: FormGroup;
  currentLocation: any = {
  lat: 0,
  lng: 0
};

    constructor(private fb: FormBuilder, public alertController: AlertController, private geolocation: Geolocation,   public router: Router) {
      this.createDirectionForm();
    }


    createDirectionForm() {
      this.directionForm = this.fb.group({
        source: ['', Validators.required],
        destination: ['', Validators.required]
      });
    }

    ngOnInit(){
     //called after the constructor and called  after the first ngOnChanges()
  }
    ngAfterViewInit(): void {
      map = new google.maps.Map(this.mapNativeElement.nativeElement, {
        zoom: 11,
        center: {lat: 1.290270, lng: 103.851959}
      });
      this.directionsDisplay.setMap(map);
      this.directionsDisplay.setPanel(this.directionsPanel.nativeElement);

    }

    async invalidRoute(status) {
      const alert = await this.alertController.create({
        header: 'Alert',
        //CHANGE THE ERROR MESSAGE
        message: 'Directions request failed due to ' + status,
        buttons: ['OK']
    });

      await alert.present();
    }

    generateRoute(formValues) {
      const that = this;
      if (scounter != 0){
          sRoute.setMap(null);
        }
      scounter = 0;
      this.directionsService.route({
        origin: formValues.source,
        destination: formValues.destination,
        travelMode: 'WALKING',
        provideRouteAlternatives: true
      }, (response, status) => {
              if (status === 'OK') {

                resp = response;
                if (gcounter != 0){
                  for (var i = 0; i<gcounter; i++){
                    gRoute[i].setMap(null);
                  }
                  gcounter = 0;
                  startMarker.setMap(null);
                  endMarker.setMap(null);
                }

                that.drawRoute(resp, 0, null);
              }
              else {
               that.invalidRoute(status);
             }

      });
      //this.router.navigate(['/home/feedback'])
    }

    drawRoute(response, checker, routenum){
      const self = this;
      var color = [
        "green",
        "red",
        "blue"
      ];
      if (checker == 0) {
        var bounds = new google.maps.LatLngBounds();
         for (var h = 0, len = response.routes.length; h < len; h++) {
           gRoute[h] = new google.maps.Polyline({
             path: [],
             strokeColor: color[h],
             strokeWeight: 3,
             zIndex:h
           });
          var legs = response.routes[h].legs;
            for (var i = 0; i < legs.length; i++) {
              var steps = legs[i].steps;
             for (var j = 0; j < steps.length; j++) {
               var nextSegment = steps[j].path;
               for (var k = 0; k < nextSegment.length; k++) {
                 gRoute[h].getPath().push(nextSegment[k]);
                 bounds.extend(nextSegment[k]);
               }
             }
           }
           map.fitBounds(bounds);
         gRoute[h].setMap(map);
         gRoute[h].addListener('click', function(e) {
            self.drawRoute(resp, 1, this.zIndex);
             });
        gcounter++;
       }
        startMarker = new google.maps.Marker({
         position:gRoute[0].getPath().getAt(0),
         label: {
           text: 'A',
           color: 'white',
         },
         map:map
        });
        endMarker =  new google.maps.Marker({
          position:gRoute[0].getPath().getAt(gRoute[0].getPath().getLength()-1),
          label: {
            text: 'B',
            color: 'white',
          },
          map:map
        });
     }
      else{
        if (gcounter != 0){
          for (var i = 0; i<gcounter; i++){
            gRoute[i].setMap(null);
          }
          gcounter = 0;
        }
        if (scounter != 0){
            sRoute.setMap(null);
            scounter = 0;
        }
        startMarker.setMap(null);
        endMarker.setMap(null);
        this.getlatandlang(response.routes[routenum].overview_path);
        sRoute = new google.maps.DirectionsRenderer({
            polylineOptions: {
              strokeColor: "black",
              strokeOpacity: 0.5
            },
            map: map,
            directions: response,
            routeIndex: routenum,

        });
        for(var i = response.routes.length-1; i >= 0; i--){
          if( i == routenum && i != 0 && i == response.routes.length-1){
          response.routes.splice(0, i);
            }
          else if( i == routenum && i != 0 && i != response.routes.length-1){
            response.routes.pop();
            response.routes.splice(0, i-1);
          }
          else{
            response.routes.splice(i, response.routes.length-1);
          }
          }
        this.directionsDisplay.setDirections(response);
        scounter++;
      }
    }


       getlatandlang(selectedroute): void{
          let latlist:string[] = [""];
          let longlist:string[] = [""];
          let latlonglist:string[] = [""];
          for (let i in selectedroute)
          {
             latlist[i] = [selectedroute[i].lat()];
             longlist[i] = [selectedroute[i].lng()];
             latlonglist[i] = latlist[i] + "," + longlist[i];
          }
          // console.log(latlist);
          // console.log(longlist);
          // console.log(latlonglist);
          this.trackroute(latlist, longlist, latlonglist)
        }




        trackroute(latlist, longlist, latlonglist): void{
            let userlatlong:string = "";
            let distCheckpoint:string = "";
            let userlocation:string = "";
            let checkpoint:string = "";
            let useronthemove:string = "";
            let counter: number = 0;
            let marker: string = "";


            //get current position
            navigator.geolocation.getCurrentPosition(function(position){
              userlatlong = (position.coords.latitude + ", " + position.coords.longitude);
              userlocation = new google.maps.LatLng(position.coords.latitude, position.coords.longitude);


            if(userlocation != latlist[latlist.length]){
               for (let i in latlist)
                {
                 checkpoint = new google.maps.LatLng(latlonglist[i]);
                 distCheckpoint = new google.maps.geometry.spherical.computeDistanceBetween(userlocation, checkpoint);
                 if(userlocation == checkpoint){
                    userlocation = checkpoint
                    checkpoint = google.maps.LatLng(latlonglist[i+1]);
                    if(!marker){
                        marker = new google.maps.Marker({
                        position: userlocation,
                        map: map
                      });
                    }else{
                      this.marker.setPosition(location);
                      console.log("new checkpoint")
                    }
                 }else{
                   if(!marker){
                       marker = new google.maps.Marker({
                       position: userlocation,
                       map: map
                     });
                   }else{
                     this.marker.setPosition(location);
                     console.log("current location")
                   }
                   break;
                 }
                }
            }else{
             console.log("COMPLETED")
            }




             //
             // if(!marker){
             //     marker = new google.maps.Marker({
             //     position: userlocation,
             //     map: map
             //   });
             // }else{
             //   this.marker.setPosition(location);
             // }

            // for (let i in latlonglist)
            //   {
            //     checkpoint = new google.maps.LatLng(latlist[i], longlist[i]);
            //     distCheckpoint = new google.maps.geometry.spherical.computeDistanceBetween(userlocation, checkpoint);
            //     console.log(userlocation)
            //     console.log(checkpoint)
            //     console.log(distCheckpoint)
            //   }


            });
           }
  }

/*
  trackroute(latlist, langlist): void{
        let userlatlang:string = "";
        let distCheckpoint:string = "";
        let userlocation:string = "";
        let checkpoint:string = "";
        let useronthemove:string = "";
        let counter: number = 0;
        let marker: string = "";

        const map = new google.maps.Map(this.mapNativeElement.nativeElement,{
          zoom: 11,
          center: {lat: 1.3521, lng: 103.8198},
          disableDefaultUI: true
        });
        this.directionsDisplay.setMap(map);

        //get current position
        navigator.geolocation.getCurrentPosition(function(position){
          userlatlang = (position.coords.latitude + ", " + position.coords.longitude);
          userlocation = new google.maps.LatLng(position.coords.latitude, position.coords.longitude);



         if(userlocation != latlist[latlist.length]){
            for (let i in latlist)
             {
              checkpoint = new google.maps.LatLng(latlist[i], langlist[i]);
              distCheckpoint = new google.maps.geometry.spherical.computeDistanceBetween(userlocation, checkpoint);
              if(userlocation == checkpoint){
                 userlocation = checkpoint
                 checkpoint = google.maps.LatLng(latlist[i + 1], langlist[i + 1]);
                 if(!marker){
                     marker = new google.maps.Marker({
                     position: userlocation,
                     map: map
                   });
                 }else{
                   this.marker.setPosition(location);
                   console.log("new checkpoint")
                 }
              }else{
                if(!marker){
                    marker = new google.maps.Marker({
                    position: userlocation,
                    map: map
                  });
                }else{
                  this.marker.setPosition(location);
                  console.log("current location")
                }
                break;
              }
             }
         }else{
          console.log("COMPLETED")
         }
        });
       }
*/
